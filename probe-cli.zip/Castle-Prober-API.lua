--[[
██████╗ ██████╗  ██████╗ ██████╗ ███████╗
██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔════╝
██████╔╝██████╔╝██║   ██║██████╔╝█████╗
██╔═══╝ ██╔══██╗██║   ██║██╔══██╗██╔══╝
██║     ██║  ██║╚██████╔╝██████╔╝███████╗
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝
  v1.2 : VM
  For Castle, by @h_jack
]]

local VM_KEY = my.variables.key
local MAX_PAYLOAD_BYTES = 250000

local function reply(actor, requestId, ok, program, problem)
    if actor then
        actor:sendMessage("castleVM.response", {
            requestId = requestId,
            ok = ok,
            program = program,
            error = problem,
        })
    end
end

local function validKey(key)
    return type(key) == "string" and #key > 0 and string.match(key, "^%d+$") ~= nil
end

local function nextStreamByte(state, keyDigit, position)
    return (state * 73 + keyDigit * 41 + position * 17 + 29) % 256
end

local function decrypt(payload)
    if not validKey(VM_KEY) then return nil, "invalid VM key" end
    if type(payload) ~= "table" or #payload == 0 then return nil, "payload is empty" end
    if #payload > MAX_PAYLOAD_BYTES then return nil, "payload is too large" end

    local output = {}
    local state = 91
    for index, encryptedByte in ipairs(payload) do
        if type(encryptedByte) ~= "number" or encryptedByte < 0
            or encryptedByte > 255 or encryptedByte % 1 ~= 0 then
            return nil, "invalid byte at " .. tostring(index)
        end
        local keyIndex = ((index - 1) % #VM_KEY) + 1
        local keyDigit = string.byte(VM_KEY, keyIndex) - 48
        state = nextStreamByte(state, keyDigit, index)
        output[index] = (encryptedByte - state - keyDigit) % 256
    end
    return output
end

local function checksum(bytes)
    local value = 1
    for index, byte in ipairs(bytes) do
        -- This modulus keeps intermediate values safe on 32-bit Lua runtimes.
        value = (value + byte * index) % 1000000007
    end
    return value
end

local function decode(bytes)
    local position = 1
    local nodes = 0

    local function readByte()
        local value = bytes[position]
        if value == nil then error("unexpected end of program") end
        position = position + 1
        return value
    end

    local function readVarint()
        local value = 0
        local scale = 1
        for _ = 1, 6 do
            local byte = readByte()
            value = value + (byte % 128) * scale
            if byte < 128 then return value end
            scale = scale * 128
        end
        error("invalid length encoding")
    end

    local function readText()
        local length = readVarint()
        if length > MAX_PAYLOAD_BYTES or position + length - 1 > #bytes then
            error("invalid text length")
        end
        local parts = {}
        for index = 1, length do parts[index] = string.char(readByte()) end
        return table.concat(parts)
    end

    local readValue
    readValue = function(depth)
        nodes = nodes + 1
        if nodes > 100000 then error("program has too many values") end
        if depth > 150 then error("program nesting is too deep") end
        local tag = readByte()
        if tag == 0 then return nil
        elseif tag == 1 then return false
        elseif tag == 2 then return true
        elseif tag == 3 then
            local value = tonumber(readText())
            if value == nil then error("invalid number") end
            return value
        elseif tag == 4 then return readText()
        elseif tag == 5 then
            local count = readVarint()
            local value = {}
            for index = 1, count do value[index] = readValue(depth + 1) end
            return value
        elseif tag == 6 then
            local count = readVarint()
            local value = {}
            for _ = 1, count do
                local key = readValue(depth + 1)
                if type(key) ~= "string" then error("map key is not a string") end
                value[key] = readValue(depth + 1)
            end
            return value
        end
        error("unknown program tag " .. tostring(tag))
    end

    local program = readValue(0)
    if position ~= #bytes + 1 then error("trailing program bytes") end
    return program
end

function onMessage(message, triggeringActor, data)
    if message ~= "castleVM.decode" then return end
    if type(data) ~= "table" then
        reply(triggeringActor, nil, false, nil, "request data must be a table")
        return
    end

    local requestId = data.requestId
    if type(requestId) ~= "string" and type(requestId) ~= "number" then
        reply(triggeringActor, requestId, false, nil, "invalid requestId")
        return
    end
    if type(data.checksum) ~= "number" then
        reply(triggeringActor, requestId, false, nil, "checksum must be a number")
        return
    end

    local bytes, decryptError = decrypt(data.payload)
    if not bytes then
        reply(triggeringActor, requestId, false, nil, decryptError)
        return
    end
    local actualChecksum = checksum(bytes)
    if actualChecksum ~= data.checksum then
        reply(triggeringActor, requestId, false, nil,
            "checksum mismatch (expected " .. tostring(data.checksum)
            .. ", got " .. tostring(actualChecksum) .. ")")
        return
    end

    local ok, program = pcall(decode, bytes)
    if not ok then
        reply(triggeringActor, requestId, false, nil, "decode failed: " .. tostring(program))
        return
    end
    reply(triggeringActor, requestId, true, program, nil)
end
