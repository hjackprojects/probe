--[[
██████╗ ██████╗  ██████╗ ██████╗ ███████╗
██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔════╝
██████╔╝██████╔╝██║   ██║██████╔╝█████╗
██╔═══╝ ██╔══██╗██║   ██║██╔══██╗██╔══╝
██║     ██║  ██║╚██████╔╝██████╔╝███████╗
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝
  v1.2 : VM
  For Castle, by @h_jack
]]
  
local VM_PAYLOAD = __CASTLE_VM_PAYLOAD__
local VM_CHECKSUM = __CASTLE_VM_CHECKSUM__
local VM_BUILD_ID = "__CASTLE_VM_BUILD_ID__"
local VM_STEP_LIMIT = 200000

local vmReady = false
local vmLoading = false
local vmEnvironment = nil
local vmSteps = 0

local function newScope(parent)
    return { values = {}, parent = parent }
end

local function scopeGet(scope, name)
    local current = scope
    while current do
        if current.values[name] ~= nil then return current.values[name] end
        current = current.parent
    end
    return nil
end

local function scopeDefine(scope, name, value)
    scope.values[name] = value
end

local function scopeAssign(scope, name, value)
    local current = scope
    while current do
        if current.values[name] ~= nil then
            current.values[name] = value
            return
        end
        current = current.parent
    end
    scope.values[name] = value
end

local function truthy(value)
    return value ~= nil and value ~= false
end

local function tick()
    vmSteps = vmSteps + 1
    if vmSteps > VM_STEP_LIMIT then error("Castle VM step limit exceeded") end
end

local evaluate
local executeBlock
local invoke

local function memberKey(node, scope)
    if node.type == "MemberExpression" then return node.identifier.name end
    return evaluate(node.index, scope)
end

local function getMember(node, scope)
    local object = evaluate(node.base, scope)
    if object == nil then error("attempt to index nil") end
    return object[memberKey(node, scope)], object
end

local function assignTarget(node, value, scope)
    if node.type == "Identifier" then
        scopeAssign(scope, node.name, value)
    elseif node.type == "MemberExpression" or node.type == "IndexExpression" then
        local object = evaluate(node.base, scope)
        object[memberKey(node, scope)] = value
    else
        error("unsupported assignment target " .. tostring(node.type))
    end
end

local function binary(operator, left, right)
    if operator == "+" then return left + right
    elseif operator == "-" then return left - right
    elseif operator == "*" then return left * right
    elseif operator == "/" then return left / right
    elseif operator == "%" then return left % right
    elseif operator == "^" then return left ^ right
    elseif operator == ".." then return tostring(left) .. tostring(right)
    elseif operator == "==" then return left == right
    elseif operator == "~=" then return left ~= right
    elseif operator == "<" then return left < right
    elseif operator == ">" then return left > right
    elseif operator == "<=" then return left <= right
    elseif operator == ">=" then return left >= right
    end
    error("unsupported binary operator " .. tostring(operator))
end

evaluate = function(node, scope)
    tick()
    local kind = node.type
    if kind == "Identifier" then return scopeGet(scope, node.name)
    elseif kind == "StringLiteral" or kind == "NumericLiteral" or kind == "BooleanLiteral" then
        return node.value
    elseif kind == "NilLiteral" then return nil
    elseif kind == "MemberExpression" or kind == "IndexExpression" then
        local value = getMember(node, scope)
        return value
    elseif kind == "LogicalExpression" then
        local left = evaluate(node.left, scope)
        if node.operator == "and" then
            if not truthy(left) then return left end
            return evaluate(node.right, scope)
        else
            if truthy(left) then return left end
            return evaluate(node.right, scope)
        end
    elseif kind == "BinaryExpression" then
        return binary(node.operator, evaluate(node.left, scope), evaluate(node.right, scope))
    elseif kind == "UnaryExpression" then
        local value = evaluate(node.argument, scope)
        if node.operator == "not" then return not truthy(value)
        elseif node.operator == "-" then return -value
        elseif node.operator == "#" then return #value
        end
        error("unsupported unary operator " .. tostring(node.operator))
    elseif kind == "TableConstructorExpression" then
        local result = {}
        local nextIndex = 1
        for _, field in ipairs(node.fields) do
            if field.type == "TableValue" then
                result[nextIndex] = evaluate(field.value, scope)
                nextIndex = nextIndex + 1
            elseif field.type == "TableKeyString" then
                result[field.key.name] = evaluate(field.value, scope)
            elseif field.type == "TableKey" then
                result[evaluate(field.key, scope)] = evaluate(field.value, scope)
            end
        end
        return result
    elseif kind == "FunctionDeclaration" then
        return { __castleVmFunction = true, node = node, closure = scope }
    elseif kind == "CallExpression" or kind == "TableCallExpression" or kind == "StringCallExpression" then
        local callable
        local selfValue = nil
        if node.base.type == "MemberExpression" then
            callable, selfValue = getMember(node.base, scope)
            if node.base.indexer ~= ":" then selfValue = nil end
        else
            callable = evaluate(node.base, scope)
        end
        local argumentNodes = node.arguments or {}
        if node.type == "TableCallExpression" then argumentNodes = { node.arguments }
        elseif node.type == "StringCallExpression" then argumentNodes = { node.argument } end
        local arguments = {}
        for index, argument in ipairs(argumentNodes) do arguments[index] = evaluate(argument, scope) end
        return invoke(callable, arguments, selfValue)
    end
    error("unsupported expression " .. tostring(kind))
end

invoke = function(callable, arguments, selfValue)
    if type(callable) == "table" and callable.__castleVmFunction then
        local callScope = newScope(callable.closure)
        for index, parameter in ipairs(callable.node.parameters or {}) do
            if parameter.type == "Identifier" then scopeDefine(callScope, parameter.name, arguments[index]) end
        end
        local signal = executeBlock(callable.node.body, callScope)
        if signal and signal.kind == "return" then return signal.values[1] end
        return nil
    end
    if type(callable) ~= "function" then error("attempt to call a non-function") end
    if selfValue ~= nil then return callable(selfValue, table.unpack(arguments)) end
    return callable(table.unpack(arguments))
end

local function executeStatement(statement, scope)
    tick()
    local kind = statement.type
    if kind == "LocalStatement" then
        local values = {}
        for index, expression in ipairs(statement.init or {}) do values[index] = evaluate(expression, scope) end
        for index, variable in ipairs(statement.variables) do scopeDefine(scope, variable.name, values[index]) end
    elseif kind == "AssignmentStatement" then
        local values = {}
        for index, expression in ipairs(statement.init) do values[index] = evaluate(expression, scope) end
        for index, variable in ipairs(statement.variables) do assignTarget(variable, values[index], scope) end
    elseif kind == "CallStatement" then
        evaluate(statement.expression, scope)
    elseif kind == "FunctionDeclaration" then
        local fn = { __castleVmFunction = true, node = statement, closure = scope }
        if statement.identifier.type ~= "Identifier" then error("member function declarations are unsupported") end
        if statement.isLocal then scopeDefine(scope, statement.identifier.name, fn)
        else scopeAssign(scope, statement.identifier.name, fn) end
    elseif kind == "ReturnStatement" then
        local values = {}
        for index, expression in ipairs(statement.arguments or {}) do values[index] = evaluate(expression, scope) end
        return { kind = "return", values = values }
    elseif kind == "BreakStatement" then
        return { kind = "break" }
    elseif kind == "IfStatement" then
        for _, clause in ipairs(statement.clauses) do
            if clause.type == "ElseClause" or truthy(evaluate(clause.condition, scope)) then
                return executeBlock(clause.body, newScope(scope))
            end
        end
    elseif kind == "WhileStatement" then
        while truthy(evaluate(statement.condition, scope)) do
            local signal = executeBlock(statement.body, newScope(scope))
            if signal then
                if signal.kind == "break" then break end
                return signal
            end
        end
    elseif kind == "ForNumericStatement" then
        local startValue = evaluate(statement.start, scope)
        local endValue = evaluate(statement["end"], scope)
        local stepValue = statement.step and evaluate(statement.step, scope) or 1
        local value = startValue
        while (stepValue >= 0 and value <= endValue) or (stepValue < 0 and value >= endValue) do
            local loopScope = newScope(scope)
            scopeDefine(loopScope, statement.variable.name, value)
            local signal = executeBlock(statement.body, loopScope)
            if signal then
                if signal.kind == "break" then break end
                return signal
            end
            value = value + stepValue
        end
    elseif kind == "ForGenericStatement" then
        local iterator = statement.iterators[1]
        if not iterator or iterator.type ~= "CallExpression" or iterator.base.type ~= "Identifier"
            or (iterator.base.name ~= "ipairs" and iterator.base.name ~= "pairs") then
            error("Castle VM supports only ipairs/pairs generic loops")
        end
        local collection = evaluate(iterator.arguments[1], scope)
        local function runPair(key, value)
            local loopScope = newScope(scope)
            if statement.variables[1] then scopeDefine(loopScope, statement.variables[1].name, key) end
            if statement.variables[2] then scopeDefine(loopScope, statement.variables[2].name, value) end
            return executeBlock(statement.body, loopScope)
        end
        if iterator.base.name == "ipairs" then
            for key, value in ipairs(collection) do
                local signal = runPair(key, value)
                if signal then
                    if signal.kind == "break" then break end
                    return signal
                end
            end
        else
            for key, value in pairs(collection) do
                local signal = runPair(key, value)
                if signal then
                    if signal.kind == "break" then break end
                    return signal
                end
            end
        end
    else
        error("unsupported statement " .. tostring(kind))
    end
    return nil
end

executeBlock = function(statements, scope)
    for _, statement in ipairs(statements or {}) do
        local signal = executeStatement(statement, scope)
        if signal then return signal end
    end
    return nil
end

local function makeEnvironment(program)
    local environment = newScope(nil)
    local builtins = {
        castle = castle, my = my, math = math, string = string, table = table,
        ipairs = ipairs, pairs = pairs, type = type, tostring = tostring,
        tonumber = tonumber, print = print,
    }
    for name, value in pairs(builtins) do scopeDefine(environment, name, value) end
    vmSteps = 0
    executeBlock(program.body, environment)
    return environment
end

local function callHandler(name, ...)
    if not vmReady then return end
    local handler = scopeGet(vmEnvironment, name)
    if handler == nil then return end
    vmSteps = 0
    local ok, problem = pcall(invoke, handler, { ... }, nil)
    if not ok then print("[Castle VM] " .. name .. " failed: " .. tostring(problem)) end
end

local function requestProgram()
    if vmLoading or vmReady then return end
    local prober = castle.closestActorWithTag("castle-vm-prober")
    if not prober then
        print("[Castle VM] No actor tagged castle-vm-prober")
        return
    end
    vmLoading = true
    prober:sendMessage("castleVM.decode", {
        requestId = VM_BUILD_ID,
        payload = VM_PAYLOAD,
        checksum = VM_CHECKSUM,
    })
end

function onCreate()
    requestProgram()
end

function onUpdate(dt)
    if vmReady then callHandler("onUpdate", dt) end
end

function onMessage(message, triggeringActor, data)
    if message == "castleVM.response" and type(data) == "table"
        and data.requestId == VM_BUILD_ID then
        vmLoading = false
        if not data.ok then
            print("[Castle VM] Prober error: " .. tostring(data.error))
            return
        end
        local ok, result = pcall(makeEnvironment, data.program)
        if not ok then
            print("[Castle VM] Program install failed: " .. tostring(result))
            return
        end
        vmEnvironment = result
        vmReady = true
        callHandler("onCreate")
        return
    end
    if vmReady then callHandler("onMessage", message, triggeringActor, data) end
end
