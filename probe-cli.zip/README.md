# Probe v1.2

This project compiles a supported subset of Castle Lua into an encrypted AST.
A prober actor decrypts and validates it, then returns the decoded program to
the requesting actor via `actor:sendMessage`. The requesting actor executes it
with the included interpreter and its own `my` context.

## CLI

```bash
probe obfuscate <inputfile> <encryptionkey> <outputfile>
```

The key must use numbers only and contain at least 9 digits.

Example:

```bash
probe obfuscate space.lua 1732810323 protected.lua
```

## Local setup

1. Run `npm install` in this folder.
2. Add an actor to the Castle card, tag it `castle-vm-prober`, and attach
   `Castle-Prober-API.lua`.
3. Install the command and compile a Castle script:

   ```bash
   npm install
   npm link
   probe obfuscate input.lua 1732810323 protected.lua
   ```

   Equivalent direct command:

   ```bash
   node castle-vm-compile.js input.lua protected.lua 1732810323
   ```

4. Attach the generated `protected.lua` to the actor that should run the input.

## Rebuild readable Lua

For files produced by this Probe VM compiler:

```bash
node probe-deobfuscate.js protected.lua deobfuscated.lua 1732810323
```

This restores readable Castle Lua from the encrypted AST. The original comments
and exact formatting cannot be restored because they are not stored.

## Supported subset

- Castle lifecycle functions and ordinary functions
- local/global variables, assignment, tables, properties and actor methods
- `if`/`elseif`/`else`, `while`, numeric `for`, and `ipairs`/`pairs` loops
- arithmetic, comparisons, logical operators, concatenation and table length
- Castle, actor, `math`, `string`, and `table` calls exposed by Castle

Unsupported syntax is rejected by the compiler. This is an interpreter, so it
is slower than native Castle Lua; avoid heavy work in `onUpdate`.

The key is present in the prober at runtime, so this is obfuscation rather than
cryptographic secrecy against someone who can inspect every shipped script.

## jsDelivr installer

After uploading this ZIP as `probe-cli.zip` to a public GitHub repository,
replace `YOUR_GITHUB_USERNAME` in `install.sh`, commit it, then install using:

```bash
curl -fsSL https://cdn.jsdelivr.net/gh/YOUR_GITHUB_USERNAME/probe@main/install.sh | sh
```
