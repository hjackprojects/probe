#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const luaparse = require("luaparse");

const inputPath = process.argv[2];
const outputPath = process.argv[3] || "Castle-VM-Protected.lua";
const key = process.argv[4] || "1732810323";
const templatePath = process.argv[5] || path.join(__dirname, "Castle-VM-Client.lua");

function fail(message) {
  console.error("Error: " + message);
  process.exit(1);
}

if (!inputPath) {
  console.log("Usage: node castle-vm-compile.js <input.lua> [output.lua] [numeric-key] [client-template.lua]");
  process.exit(0);
}
if (!/^\d+$/.test(key)) fail("key must contain numbers only");
if (!fs.existsSync(inputPath)) fail("input not found: " + inputPath);
if (!fs.existsSync(templatePath)) fail("client template not found: " + templatePath);

const source = fs.readFileSync(inputPath, "utf8");
let template = fs.readFileSync(templatePath, "utf8");

let ast;
try {
  ast = luaparse.parse(source, {
    luaVersion: "5.2",
    encodingMode: "x-user-defined",
    comments: false,
    locations: false,
    ranges: false,
    scope: false
  });
} catch (error) {
  fail("Lua parse failed: " + error.message);
}

const supportedNodes = new Set([
  "Chunk", "LocalStatement", "AssignmentStatement", "CallStatement",
  "FunctionDeclaration", "ReturnStatement", "IfStatement", "IfClause",
  "ElseifClause", "ElseClause", "ForGenericStatement", "ForNumericStatement",
  "WhileStatement", "BreakStatement", "Identifier", "StringLiteral",
  "NumericLiteral", "BooleanLiteral", "NilLiteral", "VarargLiteral",
  "TableConstructorExpression", "TableValue", "TableKey", "TableKeyString",
  "BinaryExpression", "LogicalExpression", "UnaryExpression", "MemberExpression",
  "IndexExpression", "CallExpression", "TableCallExpression", "StringCallExpression"
]);

function validate(node) {
  if (!node || typeof node !== "object") return;
  if (typeof node.type === "string" && !supportedNodes.has(node.type)) {
    fail("unsupported Castle-Lua syntax node: " + node.type);
  }
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(validate);
    else if (value && typeof value === "object") validate(value);
  }
}
validate(ast);

function clean(value) {
  if (Array.isArray(value)) return value.map(clean);
  if (!value || typeof value !== "object") return value;
  const result = {};
  for (const keyName of Object.keys(value).sort()) {
    if (["raw", "loc", "range", "comments", "isLocal"].includes(keyName)) {
      if (keyName === "isLocal") result[keyName] = value[keyName];
      continue;
    }
    result[keyName] = clean(value[keyName]);
  }
  return result;
}

const TAG_NIL = 0;
const TAG_FALSE = 1;
const TAG_TRUE = 2;
const TAG_NUMBER = 3;
const TAG_STRING = 4;
const TAG_ARRAY = 5;
const TAG_MAP = 6;

function varint(number) {
  const bytes = [];
  do {
    let byte = number % 128;
    number = Math.floor(number / 128);
    if (number > 0) byte += 128;
    bytes.push(byte);
  } while (number > 0);
  return bytes;
}

function encode(value, output = []) {
  if (value === null || value === undefined) output.push(TAG_NIL);
  else if (value === false) output.push(TAG_FALSE);
  else if (value === true) output.push(TAG_TRUE);
  else if (typeof value === "number") {
    const bytes = Buffer.from(String(value), "utf8");
    output.push(TAG_NUMBER, ...varint(bytes.length), ...bytes);
  } else if (typeof value === "string") {
    const bytes = Buffer.from(value, "utf8");
    output.push(TAG_STRING, ...varint(bytes.length), ...bytes);
  } else if (Array.isArray(value)) {
    output.push(TAG_ARRAY, ...varint(value.length));
    for (const item of value) encode(item, output);
  } else if (typeof value === "object") {
    const keys = Object.keys(value).sort();
    output.push(TAG_MAP, ...varint(keys.length));
    for (const name of keys) {
      encode(name, output);
      encode(value[name], output);
    }
  } else fail("cannot encode value type: " + typeof value);
  return output;
}

function nextStreamByte(state, keyDigit, position) {
  return (state * 73 + keyDigit * 41 + position * 17 + 29) % 256;
}

function crypt(bytes, numericKey, decrypting) {
  const output = [];
  let state = 91;
  for (let index = 0; index < bytes.length; index++) {
    const position = index + 1;
    const digit = Number(numericKey[index % numericKey.length]);
    state = nextStreamByte(state, digit, position);
    output.push(decrypting
      ? (bytes[index] - state - digit + 512) % 256
      : (bytes[index] + state + digit) % 256);
  }
  return output;
}

function checksum(bytes) {
  let value = 1;
  for (let i = 0; i < bytes.length; i++) {
    value = (value + bytes[i] * (i + 1)) % 1000000007;
  }
  return value;
}

function luaBytes(bytes) {
  const lines = [];
  for (let i = 0; i < bytes.length; i += 24) {
    lines.push("    " + bytes.slice(i, i + 24).join(", "));
  }
  return "{\n" + lines.join(",\n") + "\n}";
}

const plain = encode(clean(ast));
const encrypted = crypt(plain, key, false);
const roundTrip = crypt(encrypted, key, true);
if (!Buffer.from(roundTrip).equals(Buffer.from(plain))) fail("encryption round-trip failed");

if (!template.includes("__CASTLE_VM_PAYLOAD__")) fail("payload marker missing from client template");
if (!template.includes("__CASTLE_VM_CHECKSUM__")) fail("checksum marker missing from client template");

template = template.replace("__CASTLE_VM_PAYLOAD__", luaBytes(encrypted));
template = template.replace("__CASTLE_VM_CHECKSUM__", String(checksum(plain)));
template = template.replace("__CASTLE_VM_BUILD_ID__", crypto.randomBytes(8).toString("hex"));
fs.writeFileSync(outputPath, template, "utf8");

console.log("Castle VM client created: " + outputPath);
console.log("AST bytes: " + plain.length);
console.log("Encrypted bytes: " + encrypted.length);
console.log("Checksum: " + checksum(plain));
console.log("Dynamic Lua compilation used: no");
